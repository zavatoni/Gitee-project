#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr


class vimHostSystem():
    '''该对象，只获取;vim.HostSystem的监控巡检数据'''

    def __init__(self):
        self.dataCenter_api = sdkCorr()
        self.vsphereTool = vsphereSDK()
        self.cluster_dict = dict()

    def warningInfo(self):
        for self_itm in self.dataCenter_api.content_esxiHost():
            alarm_list = list(self_itm.triggeredAlarmState)
            if len(alarm_list) > 0:
                selfName = str(self_itm.name).split('.')[0]
                self_data = dict()
                for state_itm in range(len(alarm_list)):
                    self_data.update(
                        {
                            "key": alarm_list[state_itm].key,
                            'entityName': alarm_list[state_itm].entity.name,
                            'infoName': alarm_list[state_itm].alarm.info.name,
                            'systemName': alarm_list[state_itm].alarm.info.systemName,
                            'infoDescription': alarm_list[state_itm].alarm.info.description,
                            'overallStatus': alarm_list[state_itm].overallStatus
                        }
                    )
                    self.cluster_dict.update(
                        {
                            '{}:store-{}'.format(selfName, state_itm): self.vsphereTool.listTodict(
                                dictStr='storeName',
                                listStyle=[store_itm.name for store_itm in alarm_list[state_itm].entity.datastore]
                            ),
                            '{}:War-{}'.format(selfName, state_itm): self_data
                        }
                    )
        return self.cluster_dict

    def warningSeq(self):
        entityList = []
        for self_itm in self.dataCenter_api.content_esxiHost():
            for self_iter in self_itm.triggeredAlarmState:
                entityList.append(('entityKey', self_iter.entity), )
        return entityList


from pandas import DataFrame, ExcelWriter
from time import strftime

vspTool = vsphereSDK()


def main():
    readConfig = vspTool.vsphereConfig(configStr='Conf\Account.yml')
    for readKey in readConfig.keys():
        if len(readConfig.get(readKey)) > 0:
            cluster_frame = DataFrame.from_dict(vimHostSystem().warningInfo()).T
            with ExcelWriter(
                    'dataStore/vimHost{}Warning_{}info.xlsx'.format(strftime("%Y%m%d-%H"),
                                                                    readConfig.get(readKey)['name'])) as cf:
                cluster_frame.to_excel(cf, sheet_name='vimCluster warning Info')
        # vimCluster_frame.to_excel(cf,sheet_name='vimCluster warning Info')
        vspTool.sheetTable_Style(
            ex_str='dataStore/vimHost{}Warning_{}info.xlsx'.format(strftime("%Y%m%d-%H"), readConfig.get(readKey)['name'])
        )


if __name__ == '__main__':
    main()
