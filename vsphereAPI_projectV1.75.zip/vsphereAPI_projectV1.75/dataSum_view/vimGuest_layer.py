#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorrespond


class vimVirtualMachine():
    '''该对象，只获取;vim.VirtualMachine的监控巡检数据'''

    def __init__(self):
        self.dataCenter_api = sdkCorrespond()
        self.vsphereTool = vsphereSystem_class()
        self.cluster_dict = dict()

    def warningInfo(self):
        '''由于当前没有产生虚拟机告警因此该程序无法产生数据'''
        for self_itm in self.dataCenter_api.content_virtHost():
            print(self_itm.triggeredAlarmState)

def main():
    vimVirtualMachine().warningInfo()
if __name__ == '__main__':
    main()