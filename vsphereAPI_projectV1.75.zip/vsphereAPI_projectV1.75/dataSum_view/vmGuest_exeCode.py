#!/usr/bin/python2
# -*- coding:UTF-8 -*-
from corresPond_4layer.indexModule import sdkCorrespond


def virtHost_guest():
    for sdk_itm in sdkCorrespond().content_virtHost():
        print(sdk_itm.name)
        print(sdk_itm.overallStatus)
        # print(sdk_itm.storage)
        # print(sdk_itm.guest)
        print(sdk_itm.guest.toolsStatus)
        print(sdk_itm.guest.toolsVersionStatus)
        print(sdk_itm.guest.toolsVersionStatus2)
        print(sdk_itm.guest.toolsRunningStatus)
        print(sdk_itm.guest.toolsVersion)
        print(sdk_itm.guest.toolsInstallType)
        print(sdk_itm.guest.guestId)
        print(sdk_itm.guest.guestFamily)
        print(sdk_itm.guest.guestFullName)
        print(sdk_itm.guest.hostName)
        print(sdk_itm.guest.ipAddress)
        # break
        # print(sdk_itm.guestHeartbeatStatus)


def virtGuest_net():
    for sdk_itm in sdkCorrespond().content_virtHost():
        # print(sdk_itm.overallStatus)
        # print(sdk_itm.storage)
        if len(sdk_itm.guest.net) > 0:
            for net_itm in sdk_itm.guest.net:
                print(sdk_itm.name)
                print('network', net_itm.network)
                # if 'NoneType' not in str(type(net_itm.network)):
                #     print('network', net_itm.network)
                # if len(net_itm.ipAddress) > 0:
                #     print('ip_seq', vsphereSystem_class().listTodict('ip_address', net_itm.ipAddress))


def main():
    virtGuest_net()


# def main():
#     for sdk_itm in sdkCorrespond().content_virtHost():
#         for net_itm in sdk_itm.network:
#             print(net_itm.name)
#             print(net_itm.overallStatus)
#         print(sdk_itm.name)
#         print(sdk_itm.overallStatus)
#         print(sdk_itm.storage)
#         print(sdk_itm.guest)
#         print(sdk_itm.guestHeartbeatStatus)


if __name__ == '__main__':
    main()
