#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr
from coreLibrary.get_hosts_vswitch import GetHostsSwitches
from coreLibrary.esxi_network import capture_host_portgroups
from coreLibrary.esxi_network import capture_host_pnics
from coreLibrary.esxi_network import capture_host_vnics
from coreLibrary.esxi_network import capture_host_vswitches


class netWork():
    def __init__(self):
        self.esxi_seq = list(sdkCorr().content_esxiHost())
        self.vm_seq = vsphereSDK()
        self.set_switch = GetHostsSwitches(hosts=self.esxi_seq)
        self.sumDict = dict()

    def networkBase(self):
        esxi_seq = list(sdkCorr().content_esxiHost())
        for host_itm in esxi_seq:
            esxiName = str(host_itm.name).split('.')[0]
            esxiNum = 0
            for net_itm in host_itm.network:
                self.sumDict.update(
                    {
                        "{}:net-{}".format(esxiName, esxiNum): {
                            'name': net_itm.summary.name,
                            'accessible': net_itm.summary.accessible,
                            'overallStatus': net_itm.overallStatus,
                            'configStatus': net_itm.configStatus
                        }

                    }
                )
                esxiNum += 1
        return self.sumDict

    def get_Switchs_base(self):
        for key, val in self.set_switch.items():
            keyName = str(key.name).split('.')[0]
            for tag in range(len(val)):
                setVal = val[tag]
                self.sumDict.update(
                    {
                        keyName: {
                            'name': setVal.name,
                            'numPorts': setVal.numPorts,
                            'numPortsAvailable': setVal.numPortsAvailable,
                            'MTU': setVal.mtu
                        }
                    }
                )
        return self.sumDict

    def get_Switchs_portgroup(self):
        for host in self.esxi_seq:
            portGroup = list(capture_host_portgroups(host=host))
            if len(portGroup) > 0:
                hostKey = str(host.name).split('.')[0]
                for itm in range(len(portGroup)):
                    set_portGroup = portGroup[itm]
                    setKey = "{}:{}".format(hostKey, itm)
                    self.sumDict.update(
                        {
                            setKey: set_portGroup
                        }
                    )
        return self.sumDict

    def get_Switchs_pnics(self):
        for host in self.esxi_seq:
            pnics = list(capture_host_pnics(host=host))
            for tag in range(len(pnics)):
                hostKey = '{}:{}'.format(str(host.name).split('.')[0], tag)
                self.sumDict.update(
                    {
                        hostKey: pnics[tag]
                    }
                )
        return self.sumDict

    def get_Switchs_vnics(self):
        for host in self.esxi_seq:
            vnics = list(capture_host_vnics(host=host))
            for tag in range(len(vnics)):
                hostKey = '{}:{}'.format(str(host.name).split('.')[0], tag)
                self.sumDict.update(
                    {
                        hostKey: vnics[tag]
                    }
                )
        return self.sumDict

    def get_Switchs_vswitch(self):
        for host in self.esxi_seq:
            vswitch = list(capture_host_vswitches(host=host))
            if len(vswitch) > 0:
                for vs_itm in range(len(vswitch)):
                    setKey = "{}".format(str(host.name).split('.')[0])
                    setPnic = self.vm_seq.listTodict(
                        dictStr='pnics',
                        listStyle=vswitch[vs_itm]['pnics']
                    )
                    setPnic['name']=vswitch[vs_itm]['name']
                    setPortgroup=vsphereSDK().listTodict(
                            dictStr='portgroup',
                            listStyle=vswitch[vs_itm]['portgroups']
                        )
                    for key,val in setPortgroup.items():
                        setPnic[key]=val
                    self.sumDict.update(
                        {setKey:setPnic}
                    )
        return self.sumDict


def main():
    netWork().get_Switchs_vswitch()
    # vsphereSDK().jsonPrint(outData=netWork().get_Switchs_vnics())


if __name__ == '__main__':
    main()
