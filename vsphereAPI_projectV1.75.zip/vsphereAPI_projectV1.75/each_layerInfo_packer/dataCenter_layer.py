#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr

sdkTool = vsphereSDK()


class centerSummary():
    def __init__(self):
        self.summaryDict = dict()
        self.api = sdkCorr()
        self.center = list(self.api.content_Data_centerInfo())

    def dataStore(self):
        for case in self.center:
            for store in case.datastore:
                self.summaryDict.update(
                    {"{}-store:{}".format(case.name, store.name): {
                        'name': store.summary.name,
                        'url': store.summary.url,
                        'capacity': store.summary.capacity,
                        'freeSpace': store.summary.freeSpace,
                        'type': store.summary.type,
                        'overallStatus': case.overallStatus,
                        'configStatus': case.configStatus
                    }
                    }
                )
        return self.summaryDict

    def netWork(self):
        for case in self.center:
            net_seq = list(case.network)
            for net in range(len(net_seq)):
                set_net = net_seq[net]
                setKey = "{}-net:{}".format(case.name, net)
                self.summaryDict.update(
                    {
                        setKey: {
                            'name': set_net.name,
                            'overallStatus': set_net.overallStatus,
                            'configStatus': set_net.configStatus
                        }
                    }
                )
        return self.summaryDict

    def datastoreFolder(self):
        for case in self.center:
            self.summaryDict.update(
                {
                    "{}:Folder".format(case.name): {
                        "configStatus": case.datastoreFolder.configStatus,
                        "overallStatus": case.datastoreFolder.overallStatus
                    },
                    "{}:base".format(case.name): {
                        "configStatus": case.configStatus,
                        "overallStatus": case.overallStatus
                    }
                }
            )
        return self.summaryDict

    def networkFolder(self):
        for case in self.center:
            keyStr = "{}:net_Folder".format(case.name)
            self.summaryDict.update(
                {
                    keyStr: {
                        'overallStatus': case.networkFolder.overallStatus,
                        'configStatus': case.networkFolder.configStatus
                    }
                }
            )
        return self.summaryDict

    def parent(self):
        for case in self.center:
            keyStr = "{}:parent".format(case.name)
            self.summaryDict.update(
                {
                    keyStr: {
                        'overallStatus': case.parent.overallStatus,
                        'configStatus': case.parent.configStatus
                    }
                }
            )
        return self.summaryDict


def main():
    set_store = centerSummary().parent()
    sdkTool.jsonPrint(outData=set_store)


if __name__ == '__main__':
    main()
